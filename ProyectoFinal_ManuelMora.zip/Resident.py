class Resident:

    fullname = ""
    age = 0
    room = 0
    reservationByHours = 0
    extras[3][1] = {{},{}}
