class hotel:

# rooms = 17
# roomsAvailable = 17
# hours = 24
    def __init__(self):
        nothingYet = None
    
